--!strict

local Profile={}

Profile.Coins=0

Profile.XP=0

Profile.Level=1

Profile.Rank="Recruit"

Profile.Kills=0

Profile.Deaths=0

Profile.Assists=0

Profile.Headshots=0

Profile.Wins=0

Profile.Losses=0

Profile.PlayTime=0

Profile.LastLogin=0

Profile.Inventory={

Weapons={},

Knives={},

Skins={},

Trails={},

Effects={},

Emotes={}

}

Profile.Loadout={

Primary="Default",

Secondary="Pistol",

Knife="Knife",

Trail=nil,

KillEffect=nil

}

Profile.Settings={

Music=true,

SFX=true,

Sensitivity=1,

FOV=80

}

return Profile