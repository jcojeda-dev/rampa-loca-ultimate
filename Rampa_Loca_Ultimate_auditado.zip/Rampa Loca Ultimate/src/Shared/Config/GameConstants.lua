--!strict

local Constants = {}

----------------------------------------------------
-- GAME
----------------------------------------------------

Constants.GAME_NAME = "Rampa Loca Ultimate"

Constants.VERSION = "3.0"

Constants.MAX_PLAYERS = 8

Constants.MIN_PLAYERS = 2

----------------------------------------------------
-- MODES
----------------------------------------------------

Constants.GameModes = {

    ONE_VS_ONE = "1v1",

    FOUR_VS_FOUR = "4v4"

}

----------------------------------------------------
-- MATCH
----------------------------------------------------

Constants.Match = {

    WaitingPlayers = 2,

    Countdown = 10,

    Warmup = 15,

    RoundTime = 300,

    EndTime = 8,

    Respawn = 1

}

----------------------------------------------------
-- TEAMS
----------------------------------------------------

Constants.Teams = {

    Red = {

        Name = "Red",

        Color = BrickColor.new("Bright red")

    },

    Blue = {

        Name = "Blue",

        Color = BrickColor.new("Bright blue")

    }

}

----------------------------------------------------
-- REWARDS
----------------------------------------------------

Constants.Rewards = {

    Kill = 200,

    Headshot = 50,

    Participation = 100,

    Win1v1 = 500,

    Win4v4 = 600

}

----------------------------------------------------
-- XP
----------------------------------------------------

Constants.XP = {

    Kill = 25,

    Headshot = 10,

    Victory = 100,

    Participation = 20

}

----------------------------------------------------
-- WEAPONS
----------------------------------------------------

Constants.Weapons = {

    Primary = "Sniper",

    Secondary = "Pistol",

    Knife = "Knife"

}

----------------------------------------------------
-- PROFILE
----------------------------------------------------

Constants.DefaultProfile = {

    Coins = 0,

    XP = 0,

    Level = 1,

    Rank = "Recruit",

    Wins = 0,

    Losses = 0,

    Kills = 0,

    Deaths = 0,

    Headshots = 0,

    PlayTime = 0,

    Inventory = {},

    Loadout = {

        Primary = "Sniper",

        Secondary = "Pistol",

        Knife = "Knife"

    }

}

return Constants