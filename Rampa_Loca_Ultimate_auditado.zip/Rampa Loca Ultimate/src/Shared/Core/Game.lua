--!strict

local Game = {}

Game.__index = Game

Game._services = {}
Game._controllers = {}

function Game:RegisterService(name: string, service)
	assert(not self._services[name], `Service {name} already registered`)
	self._services[name] = service
end

function Game:RegisterController(name: string, controller)
	assert(not self._controllers[name], `Controller {name} already registered`)
	self._controllers[name] = controller
end

function Game:GetService(name: string)
	assert(self._services[name], `Service {name} not found`)
	return self._services[name]
end

function Game:GetController(name: string)
	assert(self._controllers[name], `Controller {name} not found`)
	return self._controllers[name]
end

function Game:Start()

	for _,service in pairs(self._services) do

		if service.Init then
			service:Init()
		end

	end

	for _,service in pairs(self._services) do

		if service.Start then
			task.spawn(function()
				service:Start()
			end)
		end

	end

	for _,controller in pairs(self._controllers) do

		if controller.Init then
			controller:Init()
		end

	end

	for _,controller in pairs(self._controllers) do

		if controller.Start then
			task.spawn(function()
				controller:Start()
			end)
		end

	end

end

return Game