--!strict

return table.freeze({

    Waiting = "Waiting",

    Warmup = "Warmup",

    Countdown = "Countdown",

    Playing = "Playing",

    Ending = "Ending",

    Restarting = "Restarting"

})