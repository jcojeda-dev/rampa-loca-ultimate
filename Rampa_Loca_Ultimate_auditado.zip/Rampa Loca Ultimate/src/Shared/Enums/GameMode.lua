--!strict

return table.freeze({

    OneVsOne = "1v1",

    FourVsFour = "4v4"

})