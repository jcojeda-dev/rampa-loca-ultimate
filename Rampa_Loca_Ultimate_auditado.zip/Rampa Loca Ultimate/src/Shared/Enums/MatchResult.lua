--!strict

return table.freeze({

    Red = "Red",

    Blue = "Blue",

    Draw = "Draw"

})