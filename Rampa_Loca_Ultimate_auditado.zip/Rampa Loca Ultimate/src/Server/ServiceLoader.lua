--!strict

local ServerScriptService = game:GetService("ServerScriptService")

local ServicesFolder = ServerScriptService.Services

local ServiceLoader = {}

function ServiceLoader:Load()

	for _, module in ipairs(ServicesFolder:GetChildren()) do

		if module:IsA("ModuleScript") then

			local service = require(module)

			if service.Start then

				service:Start()

			end

		end

	end

end

return ServiceLoader