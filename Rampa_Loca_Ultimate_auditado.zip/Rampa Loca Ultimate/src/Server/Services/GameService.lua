--!strict

local RunService = game:GetService("RunService")

local GameService = {}

GameService.__index = GameService

GameService.Started = false

GameService.Version = "3.0.0"

GameService.TickRate = 60

GameService.Services = {}

function GameService:RegisterService(name, service)

	assert(service, "Service nil")

	self.Services[name] = service

	print("[GameService] Registered ->", name)

end

function GameService:GetService(name)

	return self.Services[name]

end

function GameService:Start()

	if self.Started then

		return

	end

	self.Started = true

	print("=================================")
	print("Rampa Loca Ultimate")
	print("Version "..self.Version)
	print("Starting Services...")
	print("=================================")

	for _,service in pairs(self.Services) do

		if service.Start then

			service:Start()

		end

	end

	RunService.Heartbeat:Connect(function(dt)

		self:Update(dt)

	end)

end

function GameService:Update(dt)

	for _,service in pairs(self.Services) do

		if service.Update then

			service:Update(dt)

		end

	end

end

return GameService