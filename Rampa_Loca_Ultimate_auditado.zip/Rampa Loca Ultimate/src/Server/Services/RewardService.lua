--!strict

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Constants = require(ReplicatedStorage.Shared.Config.GameConstants)

local RewardService = {}

RewardService.__index = RewardService

------------------------------------------------

function RewardService:GetKillReward()

    return Constants.Rewards.Kill

end

------------------------------------------------

function RewardService:GetHeadshotReward()

    return Constants.Rewards.Headshot

end

------------------------------------------------

function RewardService:GetParticipationReward()

    return Constants.Rewards.Participation

end

------------------------------------------------

function RewardService:GetVictoryReward(mode)

    if mode == Constants.GameModes.ONE_VS_ONE then

        return Constants.Rewards.Win1v1

    end

    return Constants.Rewards.Win4v4

end

------------------------------------------------

return RewardService