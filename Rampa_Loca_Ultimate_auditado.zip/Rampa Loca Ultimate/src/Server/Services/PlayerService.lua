--!strict

local Players = game:GetService("Players")

local PlayerService = {}

PlayerService.__index = PlayerService

type PlayerProfile = {

	UserId:number,

	Name:string,

	Loaded:boolean,

	Data:any

}

PlayerService.Profiles = {}

PlayerService.PlayerAddedSignal = Instance.new("BindableEvent")

PlayerService.PlayerRemovingSignal = Instance.new("BindableEvent")

-------------------------------------------------

function PlayerService:Init()

	print("[PlayerService] Init")

end

-------------------------------------------------

function PlayerService:Start()

	Players.PlayerAdded:Connect(function(player)

		self:AddPlayer(player)

	end)

	Players.PlayerRemoving:Connect(function(player)

		self:RemovePlayer(player)

	end)

	for _,player in ipairs(Players:GetPlayers()) do

		self:AddPlayer(player)

	end

end

-------------------------------------------------

function PlayerService:AddPlayer(player:Player)

	if self.Profiles[player.UserId] then

		return

	end

	local profile:PlayerProfile={

		UserId=player.UserId,

		Name=player.Name,

		Loaded=false,

		Data=nil

	}

	self.Profiles[player.UserId]=profile

	self.PlayerAddedSignal:Fire(player)

end

-------------------------------------------------

function PlayerService:RemovePlayer(player:Player)

	self.PlayerRemovingSignal:Fire(player)

	self.Profiles[player.UserId]=nil

end

-------------------------------------------------

function PlayerService:SetData(player:Player,data)

	local profile=self.Profiles[player.UserId]

	if not profile then

		return

	end

	profile.Data=data

	profile.Loaded=true

end

-------------------------------------------------

function PlayerService:GetData(player:Player)

	local profile=self.Profiles[player.UserId]

	if not profile then

		return nil

	end

	return profile.Data

end

-------------------------------------------------

function PlayerService:GetProfile(player:Player)

	return self.Profiles[player.UserId]

end

-------------------------------------------------

function PlayerService:IsLoaded(player:Player)

	local profile=self.Profiles[player.UserId]

	if not profile then

		return false

	end

	return profile.Loaded

end

-------------------------------------------------

return PlayerService