--!strict

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Folder = Instance.new("Folder")

Folder.Name = "Remotes"

Folder.Parent = ReplicatedStorage

local RemoteService = {}

RemoteService.Events = {}

RemoteService.Functions = {}

function RemoteService:RegisterEvent(name)

	if self.Events[name] then

		return self.Events[name]

	end

	local remote = Instance.new("RemoteEvent")

	remote.Name = name

	remote.Parent = Folder

	self.Events[name] = remote

	return remote

end

function RemoteService:RegisterFunction(name)

	if self.Functions[name] then

		return self.Functions[name]

	end

	local remote = Instance.new("RemoteFunction")

	remote.Name = name

	remote.Parent = Folder

	self.Functions[name] = remote

	return remote

end

return RemoteService