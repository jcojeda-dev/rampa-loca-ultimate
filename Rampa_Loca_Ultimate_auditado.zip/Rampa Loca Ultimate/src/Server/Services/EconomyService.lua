--!strict

local EconomyService={}

EconomyService.__index=EconomyService

-------------------------------------------------

function EconomyService:AddCoins(profile,amount)

	assert(profile)

	profile.Coins+=amount

end

-------------------------------------------------

function EconomyService:RemoveCoins(profile,amount)

	assert(profile)

	if profile.Coins<amount then

		return false

	end

	profile.Coins-=amount

	return true

end

-------------------------------------------------

function EconomyService:SetCoins(profile,amount)

	profile.Coins=amount

end

-------------------------------------------------

function EconomyService:GetCoins(profile)

	return profile.Coins

end

-------------------------------------------------

return EconomyService