--!strict

local DataStoreService=game:GetService("DataStoreService")

local HttpService=game:GetService("HttpService")

local ReplicatedStorage=game:GetService("ReplicatedStorage")

local Template=require(ReplicatedStorage.Shared.Config.ProfileTemplate)

local Store=DataStoreService:GetDataStore("RLU_PROFILE_V1")

local DataService={}

DataService.__index=DataService

-----------------------------------------------------

local function DeepCopy(tbl)

	local new={}

	for k,v in pairs(tbl) do

		if type(v)=="table" then

			new[k]=DeepCopy(v)

		else

			new[k]=v

		end

	end

	return new

end

-----------------------------------------------------

function DataService:CreateProfile()

	return DeepCopy(Template)

end

-----------------------------------------------------

function DataService:Load(player)

	local success,data=pcall(function()

		return Store:GetAsync(player.UserId)

	end)

	if not success then

		warn("Failed Loading "..player.Name)

		return self:CreateProfile()

	end

	if data==nil then

		data=self:CreateProfile()

	end

	data.LastLogin=os.time()

	return data

end

-----------------------------------------------------

function DataService:Save(player,data)

	local success,errorMessage=pcall(function()

		Store:SetAsync(player.UserId,data)

	end)

	if not success then

		warn(errorMessage)

	end

end

-----------------------------------------------------

return DataService