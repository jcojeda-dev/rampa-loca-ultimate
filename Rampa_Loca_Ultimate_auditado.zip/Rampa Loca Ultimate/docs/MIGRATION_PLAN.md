# MIGRATION_PLAN.md

Plan de corrección de los hallazgos 🟠/🟡 de `TECH_DEBT.md` que requieren decisión de
diseño (no auto-corregibles). Cada fase es independiente y desbloquea la siguiente.
**Ninguna fase incluye gameplay, armas, HUD ni `MatchService`** — eso empieza después de
la fase 3, según `ROADMAP.md`.

## Fase 0 — Toolchain y paquetes (prerequisito)

1. Instalar `aftman` y ejecutar `aftman install` (usa `aftman.toml`).
2. Ejecutar `wally install` para materializar `Packages/`.
3. Añadir a `default.project.json`:
   ```json
   "ReplicatedStorage": {
     "$path": "src/Replicated",
     "Shared": { "$path": "src/Shared" },
     "Packages": { "$path": "Packages" }
   }
   ```
4. Configurar CI (ver `ROADMAP.md`) para que estos pasos corran en cada PR — evita que
   vuelva a ocurrir lo que pasó con el mapeo de `Shared` (bug crítico #1 de
   `TECH_DEBT.md`, invisible durante meses porque nada validaba `rojo build`).

**Criterio de salida:** `rojo build -o build.rbxl` termina sin error; `Packages` visible
en `ReplicatedStorage` dentro de Studio.

## Fase 1 — Consolidación de configuración y perfil de jugador

1. Elegir una única fuente de verdad por dominio (recomendado, dado el estado actual):
   - `MatchConfig.lua` absorbe los campos de partida de `GameConfig` y `GameConstants.Match`.
   - `EconomyConfig.lua` absorbe `GameConstants.Rewards` (incluyendo el `Assist` que
     falta en un lado y sobra en el otro — decidir el valor correcto con diseño de
     juego, no asumirlo).
   - `GameConfig.lua` se reduce a metadatos globales (nombre, versión, flags de
     features) y deja de duplicar tiempos de partida.
   - `GameConstants.lua` se retira una vez migrados sus campos únicos, o se convierte en
     un simple re-export de los tres archivos anteriores para no romper `require`s
     existentes durante la transición.
2. Unificar el perfil por defecto en `ProfileTemplate.lua` como única forma válida.
   `GameConstants.DefaultProfile` y `ProfileService.DefaultProfile` se eliminan y sus
   usos (hoy ninguno real, ver `DEPENDENCY_GRAPH.md`) se redirigen a `ProfileTemplate`.
3. Documentar el esquema final del perfil con un `type Profile = {...}` en
   `Shared/Types/` (carpeta ya reservada, actualmente vacía).

**Criterio de salida:** un solo archivo por concepto de balance; `selene` no reporta
variables/tablas duplicadas; existe un `type Profile` versionado.

## Fase 2 — Unificación del orquestador y persistencia

1. Confirmar `Shared/Core/Game.lua` como único punto de registro (ya es el único
   `require`do por ambos, cliente y servidor — ver `DEPENDENCY_GRAPH.md`).
2. Migrar cada `Service` para que se registre explícitamente en `Bootstrap.server.lua`
   vía `Game:RegisterService("NombreService", require(...))`, y análogamente cada
   `Controller` en `Bootstrap.client.lua`.
3. Retirar `GameService.lua`, `ServiceRegistry.lua` y `ServiceLoader.lua` una vez
   confirmado que ningún código externo los referencia (hoy no lo hace — ver
   `DEPENDENCY_GRAPH.md`).
4. Reemplazar el acceso directo a `DataStoreService` en `DataService.lua` por
   `ProfileStore` (paquete ya declarado). Mantener la firma pública de `DataService`
   (`:Load`, `:Save`, `:CreateProfile`) para no romper a quien ya lo consuma.
5. Migrar `RemoteService.lua` de creación en runtime a remotos estáticos bajo
   `src/Replicated/Remotes/`, uno por archivo/carpeta, documentando el payload
   esperado junto a cada remoto.

**Criterio de salida:** `Bootstrap.server.lua`/`Bootstrap.client.lua` arrancan todos los
`Service`/`Controller` existentes sin error; `DataService` sobrevive un `SetAsync`
concurrente simulado sin corromper datos.

## Fase 3 — Estandarización de eventos y limpieza de estilo

1. Decidir una única primitiva de evento: adoptar `sleitnick/signal` (Wally) y retirar
   `Shared/Modules/Signal.lua`, o formalizar la implementación propia como estándar y
   quitar la dependencia de Wally. Aplicar la misma decisión a `Promise`.
2. Migrar `PlayerService.lua` de `BindableEvent` a la primitiva elegida en el paso 1.
3. Ejecutar `stylua .` y `selene .` sobre todo `src/` y corregir lo que reporten.
4. Pasar todos los `print()` de debug restantes por `Shared/Core/Logger`.
5. Añadir `--!strict` a los módulos listados en `TECH_DEBT.md` #16.

**Criterio de salida:** `stylua --check .` y `selene .` en verde; un único patrón de
eventos en todo el codebase.

---

A partir de aquí, con arranque, configuración, persistencia y networking consolidados,
el proyecto queda en condiciones de iniciar desarrollo de gameplay (armas, HUD,
`MatchService`), fuera del alcance de esta auditoría — ver `ROADMAP.md`.
