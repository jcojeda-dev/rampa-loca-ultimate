# SECURITY_PLAN.md

## 1. Principio rector (ya declarado en `README.md`/`CLAUDE.md`, formalizado aquí)

El servidor es la única autoridad sobre:

- Monedas / economía → siempre vía `EconomyService`, nunca `leaderstats` directo.
- Vida / daño → siempre vía el futuro `CombatService`, nunca `Humanoid.Health` directo.
- Datos persistentes → siempre vía `DataService`, nunca `DataStoreService` desde otro
  módulo.

Esta auditoría no encontró violaciones de este principio en el código actual (el código
actual apenas tiene superficie de ataque real porque casi nada está conectado — ver
`DEPENDENCY_GRAPH.md`). El riesgo es que se viole **al conectar las piezas** sin esta
guía presente, por eso se documenta ahora, antes del gameplay.

## 2. Superficie de red

Estado actual: `RemoteService.lua` puede registrar `RemoteEvent`/`RemoteFunction`, pero
ninguno está conectado a un handler todavía (`ServiceRegistry`/`GameService` no arrancan
— `TECH_DEBT.md` #6). Antes de conectar el primer remoto a lógica real:

1. **Validación de tipo y forma en cada handler**, nunca confiar en el tipo que Roblox
   reporta del lado del cliente (`RemoteEvent:FireServer` puede enviar cualquier tipo).
   Usar `typeof()` + rangos explícitos antes de tocar cualquier `Service`.
2. **Rate limiting por jugador** en servidor para cada remoto (ej. tabla
   `lastFireTime[player]` con `os.clock()`), independiente de cualquier cooldown que
   implemente el cliente.
3. **Nunca enviar el resultado de una validación de otro jugador** a un cliente que no
   sea el implicado (evitar filtrar posiciones/inventarios de otros jugadores por remotos
   mal segmentados).
4. Los remotos deben nacer **estáticos** (`src/Replicated/Remotes/`, ver
   `ARCHITECTURE.md` §3 y `MIGRATION_PLAN.md` fase 2) para que cualquier revisor pueda
   auditar la superficie completa de red sin leer runtime.

## 3. Economía

`EconomyService:AddCoins`/`RemoveCoins`/`SetCoins` reciben `profile` y `amount` sin
validar (`assert(profile)` solo verifica que no sea `nil`, no que `amount` sea un número
positivo válido). Antes de exponer cualquiera de estos métodos a un remoto:

- Validar `type(amount) == "number"`, `amount == amount` (descartar `NaN`), `amount >= 0`
  y un límite superior razonable por llamada (evita overflow/abuso vía un solo evento).
- `RemoveCoins` ya verifica saldo insuficiente (`profile.Coins < amount`) — patrón
  correcto, replicar en cualquier método económico nuevo.
- Ningún método económico debe ser alcanzable **directamente** desde un remoto; siempre
  a través de un evento de servidor verificado (ej. "jugador ganó una ronda" calculado
  en servidor, no reportado por el cliente).

## 4. Persistencia

- Migrar a `ProfileStore` (`MIGRATION_PLAN.md` fase 2) resuelve el riesgo de doble
  sesión (mismo jugador con dos servidores escribiendo el mismo perfil) vía
  session-locking — riesgo real hoy con `DataStoreService` crudo en `DataService.lua`.
- `DataService:Load` ya usa `pcall` y tiene fallback a perfil nuevo ante fallo de
  `GetAsync` — correcto para disponibilidad, pero **debe loggear** (vía `Logger`, no
  `warn` suelto) cada fallback para poder auditar pérdida de datos en producción.
- Nunca confiar en datos que vienen de `DataStoreService` sin validar su forma contra
  el `type Profile` (ver `MIGRATION_PLAN.md` fase 1) — un perfil corrupto o de una
  versión de esquema anterior no debe poder crashear un `Service`.

## 5. Anti-cheat

`GameConfig.EnableAntiCheat = true` ya está declarado como flag, pero no existe ningún
sistema detrás. Antes de implementarlo (fuera de alcance de esta auditoría):

- Cualquier validación de posición/velocidad/daño debe vivir en servidor, nunca confiar
  en telemetría reportada por el cliente sin contrastarla contra límites físicos
  conocidos (velocidad máxima, cadencia de disparo del arma equipada, etc.).
- El flag `EnableAntiCheat` debe controlar la activación del sistema sin requerir
  cambios de código — útil para poder desactivarlo rápido en caso de falso positivo
  masivo en producción.

## 6. Secretos y configuración sensible

- `.env`/`.env.*` ya están excluidos de git (ver `.gitignore`, corregido en esta
  sesión) con `.env.example` como plantilla sin valores reales.
- Ninguna API key, token o credencial debe pegarse jamás en el chat, en un commit, ni en
  ningún archivo de `docs/`. Si una credencial se expone accidentalmente en cualquier
  canal, se considera comprometida y debe revocarse/regenerarse de inmediato.
- `HttpService` (usado por `DataService.lua` vía `game:GetService("HttpService")`,
  aunque sin llamada real todavía) debe usarse únicamente contra endpoints propios o de
  confianza explícita; cualquier integración externa futura necesita su credencial vía
  variable de entorno / `HttpService:GetAsync` con la key inyectada en runtime, nunca
  hardcodeada en un `.lua`.

## 7. Checklist previo a conectar el primer remoto real

- [ ] Remoto definido de forma estática en `src/Replicated/Remotes/`.
- [ ] Handler en servidor valida tipo y rango de cada argumento.
- [ ] Rate limit por jugador implementado.
- [ ] Ninguna mutación de economía/vida/datos ocurre fuera de su `Service` dueño.
- [ ] Log de la acción vía `Shared/Core/Logger`, no `print`/`warn` sueltos.
