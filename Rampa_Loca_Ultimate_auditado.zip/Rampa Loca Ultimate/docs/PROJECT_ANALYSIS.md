# PROJECT_ANALYSIS.md

**Proyecto:** Rampa Loca Ultimate
**Tipo:** Framework FPS para Roblox (Rojo + Wally)
**Fecha de auditoría:** 2026-07-10
**Auditor:** Principal Roblox Software Architect (Claude)
**Alcance:** Auditoría estructural completa. No incluye gameplay, armas, HUD ni MatchService.

## 1. Resumen ejecutivo

El repositorio contiene un **scaffold temprano**, no un framework funcional. De 26 archivos
Luau, solo 6 tenían contenido detectable por herramientas estándar (`wc -l`); los 20
restantes usaban finales de línea `CR` puro (estilo Mac clásico de 1984), lo que ocultaba
que en realidad **sí tienen contenido** (hasta 160 líneas). Este hallazgo por sí solo
invalidaba cualquier lint, diff o revisión de código previa.

Tras normalizar los finales de línea, la auditoría revela un patrón claro: **el código
individual está razonablemente bien escrito** (tipado `--!strict`, `pcall` en operaciones
de red, `task.spawn`/`task.wait` en vez de `spawn`/`wait`), pero **la integración entre
piezas está rota o duplicada**. El proyecto, en su estado recibido, **no podía arrancar**.

## 2. Hallazgos críticos (bloqueantes) — corregidos en esta auditoría

| # | Hallazgo | Severidad | Estado |
|---|----------|-----------|--------|
| 1 | `ReplicatedStorage.Shared` nunca se sincronizaba (faltaba en `default.project.json`). Todo el bootstrap (`Bootstrap.server.lua`, `Bootstrap.client.lua`) y varios servicios hacen `require(ReplicatedStorage.Shared...)` → el juego no podía iniciar en ningún lado. | 🔴 Crítica | ✅ Corregido |
| 2 | `default.project.json` apuntaba a `src/Client` (mayúscula) pero la carpeta real era `src/client` (minúscula). En sistemas case-sensitive (Linux CI, GitHub Actions) `rojo build`/`serve` falla. | 🔴 Crítica | ✅ Corregido (carpeta renombrada) |
| 3 | `DataService.lua` usaba un `require` relativo (`script.Parent.Parent.Parent.Shared...`) que resuelve a `game.Shared`, inexistente. Persistencia de datos rota. | 🔴 Crítica | ✅ Corregido |
| 4 | Todos los archivos de texto usaban `CRLF` o `CR` puro, violando `stylua.toml` (`line_endings = "Unix"`) y rompiendo herramientas de línea (`grep -n`, `git diff`, `wc -l`). | 🟠 Alta | ✅ Corregido |
| 5 | 20 directorios vacíos (`src/Lighting`, `src/UI`, `src/Sounds`, `src/Workspace`, etc.) no estaban versionados — Git no rastrea carpetas vacías. Un clon fresco rompería el árbol de Rojo. | 🟠 Alta | ✅ Corregido (`.gitkeep`) |

## 3. Hallazgos estructurales (requieren decisión de diseño, no auto-corregibles)

Ver detalle completo en `TECH_DEBT.md` y `MIGRATION_PLAN.md`. Resumen:

- **4 mecanismos de arranque/DI compitiendo sin coordinación**: `Shared/Core/Game.lua`,
  `Server/Services/GameService.lua`, `Server/Services/ServiceRegistry.lua` y
  `Server/ServiceLoader.lua` implementan patrones de registro de servicios distintos y
  ninguno está conectado a los demás. Ningún servicio real (`DataService`,
  `EconomyService`, `PlayerService`, etc.) se registra jamás en `Game.lua`, que es el
  único invocado desde `Bootstrap.server.lua`.
- **Configuración de juego fragmentada en 5 archivos** (`GameConfig`, `GameConstants`,
  `MatchConfig`, `EconomyConfig`, `ProfileTemplate`/`ProfileService.DefaultProfile`) con
  valores duplicados y **algunos inconsistentes entre sí** (ej. `Intermission`: 12 en
  `GameConfig`, 10 en `MatchConfig`, sin equivalente claro en `GameConstants`).
- **3 formas distintas del "perfil por defecto" del jugador**, con campos y estructuras
  de `Inventory`/`Loadout` incompatibles entre `GameConstants.DefaultProfile`,
  `ProfileTemplate.lua` y `ProfileService.DefaultProfile`.
- **Dependencias de Wally declaradas pero no usadas**: `wally.toml` declara
  `evaera/promise`, `sleitnick/signal`, `sleitnick/trove`, `sleitnick/comm`,
  `lm-loleris/profilestore`, pero el código usa implementaciones caseras de
  `Promise`/`Signal` (`Shared/Modules/`) y acceso directo a `DataStoreService` en vez de
  `ProfileStore`. No existe carpeta `Packages/` ni mapeo en `default.project.json`.
- **Doble convención de networking**: `RemoteService.lua` crea remotos en tiempo de
  ejecución vía `Instance.new`, mientras `src/Replicated/Remotes/` existe como carpeta
  estática de Rojo (vacía). No hay una única fuente de verdad.

## 4. Aspectos positivos a preservar

- Uso consistente de `--!strict` en casi todos los módulos.
- `task.spawn`/`task.wait` en vez de `spawn`/`wait` (cumple `CLAUDE.md`).
- `pcall` alrededor de operaciones `DataStoreService`.
- `table.freeze` en los Enums (`GameMode`, `MatchResult`, `MatchState`).
- Reglas de proyecto ya documentadas (`README.md`, `CLAUDE.md`) son razonables y alineadas
  con buenas prácticas de Roblox (nunca modificar `Humanoid.Health`/monedas directamente,
  límite de 400 líneas por archivo, nombres descriptivos).

## 5. Estado del repositorio Git

El repositorio no tenía commits (`0 commits`, working tree completo sin trackear).
Se estableció una línea base y las correcciones estructurales en commits separados
y revisables (ver `git log`). No se han creado remotos ni se ha hecho push: esta
sesión no cuenta con credenciales de GitHub.

## 6. Veredicto

El proyecto **no está listo para desarrollo de gameplay**. Antes de escribir armas, HUD o
`MatchService`, se debe: (a) unificar el patrón de arranque/DI, (b) consolidar la
configuración en una única fuente de verdad, (c) decidir el uso real de los paquetes de
Wally ya declarados. Ver `MIGRATION_PLAN.md` y `ROADMAP.md` para el plan de corrección.
