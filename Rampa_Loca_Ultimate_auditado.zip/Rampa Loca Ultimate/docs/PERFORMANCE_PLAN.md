# PERFORMANCE_PLAN.md

Un FPS de 8 jugadores (`GameConfig.MaxPlayers = 8`, modo `4v4`) tiene presupuesto de
frame y de red mucho más ajustado que un juego casual. Este documento fija los
lineamientos de rendimiento que el framework debe respetar desde su base, antes de que
exista una sola arma o sistema de combate.

## 1. Hallazgos actuales relevantes

- `Shared/Modules/Promise.lua:Await()` hace espera activa
  (`repeat task.wait() until self._resolved or self._rejected`). En un framework FPS,
  cualquier `Service`/`Controller` que dependa de esto para lógica por-jugador
  multiplicaría busy-waits por 8 jugadores simultáneos. Ver corrección en
  `MIGRATION_PLAN.md` fase 3 (adoptar `evaera/promise`, que resuelve por callback, no
  por polling).
- `GameService.lua` conecta `RunService.Heartbeat` y recorre `self.Services` cada frame
  llamando `:Update(dt)` si existe — patrón correcto, pero está en el registry
  **deprecado** (`TECH_DEBT.md` #6). El orquestador único (`Shared/Core/Game.lua`) no
  tiene aún un bucle de `Update` — debe incorporarlo al unificarse (`MIGRATION_PLAN.md`
  fase 2), usando `RunService.Heartbeat` en servidor y `RunService.RenderStepped`/
  `Heartbeat` según corresponda en cliente.
- `GameConfig.AutoSaveInterval = 60` (segundos) ya está declarado — correcto para no
  saturar `DataStoreService` (límite real de Roblox: ~60 escrituras/min por store,
  compartido entre todos los jugadores del servidor).

## 2. Presupuesto de red

- Todo `RemoteEvent` de alta frecuencia (posición, disparo, hit-registration) debe
  throttlearse en servidor independientemente de la tasa del cliente — nunca confiar en
  que el cliente respete un cooldown.
- `RemoteFunction` está reservado para consultas puntuales (ej. "dame mi inventario al
  entrar"), nunca para lógica de combate por el costo de yield que implica.
- Cuando se implemente `MatchService` (fuera de alcance aquí), preferir replicar
  **estado**, no eventos discretos, para todo lo que deba tolerar paquetes perdidos
  (posición de jugadores, timer de ronda).

## 3. DataStore

- Presupuesto real de Roblox: ~60 + (# jugadores × 10) escrituras/min por
  `DataStore`. Con 8 jugadores eso es ~140/min — suficiente para autosave cada 60s
  (8 escrituras/min) más guardado al salir, pero **sin margen para escrituras por
  cada transacción económica individual** (ej. no hacer `SetAsync` en cada kill).
  `EconomyService`/`RewardService` deben acumular en memoria y persistir solo en
  autosave/salida — patrón ya implícito en `DataService:Save(player, data)`
  (guarda el perfil completo, no campos sueltos). Mantener esa forma.
- Migrar a `ProfileStore` (ver `MIGRATION_PLAN.md` fase 2) también resuelve
  reintentos con backoff exponencial ante `Store:GetAsync`/`SetAsync` fallidos, que
  hoy `DataService.lua` solo reintenta implícitamente vía `pcall` sin backoff.

## 4. Memoria y objetos

- `Client/Effects`, `Client/Weapons` (vacíos, fuera de alcance) deberán usar object
  pooling para efectos de disparo/impacto en vez de `Instance.new`/`Destroy` por evento
  — dejar esto establecido como regla antes de que se escriba la primera arma
  (ver `ROADMAP.md`).
- `Trove` (`sleitnick/trove`, ya en `wally.toml`, sin usar — `TECH_DEBT.md` #12) es el
  mecanismo recomendado para limpieza determinista de conexiones en `Controllers` con
  ciclo de vida corto (ej. UI de partida, efectos de ronda).

## 5. Server-side load

- `GameConfig.TickRate` no existe como tal; `GameService.TickRate = 60` está declarado
  pero no se usa para nada (no hay ningún `wait(1/60)` ni limitador — el bucle real
  depende de `RunService.Heartbeat`, que ya corre a la tasa del servidor). Al unificar
  el orquestador (fase 2 de `MIGRATION_PLAN.md`), decidir si `TickRate` se elimina por
  redundante o se usa para limitar explícitamente la frecuencia de `Update` de sistemas
  costosos (ej. anti-cheat, ver `SECURITY_PLAN.md`).

## 6. Métricas a instrumentar antes de gameplay

1. Tiempo de `Bootstrap` (server y client) hasta `Game:Start()` completo.
2. Conteo de `RemoteEvent`s disparados por segundo por jugador (una vez exista
   `MatchService`).
3. Latencia de `DataService:Load`/`:Save` (p50/p95).
4. Memoria de `Packages` + `Shared` tras instalar dependencias reales (fase 0 de
   `MIGRATION_PLAN.md`) — hoy no medible porque `Packages/` no existe.
