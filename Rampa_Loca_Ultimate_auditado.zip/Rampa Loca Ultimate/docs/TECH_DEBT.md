# TECH_DEBT.md

Formato: `[Severidad] Título — Ubicación — Estado`. Ordenado por severidad, luego por
esfuerzo estimado de corrección (menor primero).

## 🔴 Crítica — corregida en esta auditoría

1. **`ReplicatedStorage.Shared` no sincronizado** — `default.project.json` — ✅ Corregido.
2. **`src/Client` vs `src/client` (case mismatch)** — `default.project.json` / carpeta —
   ✅ Corregido.
3. **`require` roto en `DataService.lua`** (`script.Parent.Parent.Parent.Shared...` →
   `game.Shared`, inexistente) — ✅ Corregido.
4. **Finales de línea no estándar (`CR`/`CRLF`) en todo el repo** — ✅ Corregido.
5. **20 directorios vacíos sin versionar** (rompían `rojo build` en clon limpio) —
   ✅ Corregido con `.gitkeep`.

## 🟠 Alta — pendiente, requiere decisión de diseño

6. **4 mecanismos de arranque/DI compitiendo**: `Shared/Core/Game.lua`,
   `Server/Services/GameService.lua`, `Server/Services/ServiceRegistry.lua`,
   `Server/ServiceLoader.lua`. Ninguno registra a los servicios reales. Consecuencia:
   **ningún `Service` arranca hoy**, aunque `Bootstrap.server.lua` se ejecute sin error.
   — Plan: `MIGRATION_PLAN.md` fase 1.

7. **Configuración de balance fragmentada en 5 archivos con valores inconsistentes**:

   | Concepto | `GameConfig` | `GameConstants` | `MatchConfig` | `EconomyConfig` |
   |---|---|---|---|---|
   | Intermission/EndTime | 12 | 8 (`EndTime`) | 10 | — |
   | AssistReward | — | — (no existe `Assist` en `Rewards`) | — | 75 |

   Cualquier lectura futura de "tiempo de intermisión" o "recompensa de asistencia"
   dará un resultado distinto según qué archivo se consulte. — Plan: `MIGRATION_PLAN.md`
   fase 1.

8. **3 formas incompatibles del perfil por defecto del jugador**
   (`GameConstants.DefaultProfile`, `ProfileTemplate.lua`, `ProfileService.DefaultProfile`)
   con distinta forma de `Inventory` (plano vs. por categorías) y distinto valor por
   defecto de `Loadout.Primary` (`"Sniper"` vs `"Default"`). Es el hallazgo de mayor
   riesgo de bug silencioso en producción (pérdida/corrupción de datos de jugador). —
   Plan: `MIGRATION_PLAN.md` fase 1, antes de tocar `DataService` en producción.

9. **Persistencia sin `ProfileStore`**: `DataService.lua` usa `DataStoreService`
   directamente pese a que `lm-loleris/profilestore` ya está declarado en `wally.toml`.
   Sin session-locking, sin reintentos, sin protección ante `SetAsync` concurrente. —
   Plan: `MIGRATION_PLAN.md` fase 2.

10. **Doble convención de networking**: `RemoteService.lua` crea remotos vía
    `Instance.new` en runtime; `src/Replicated/Remotes/` existe como carpeta estática
    vacía. — Plan: `MIGRATION_PLAN.md` fase 2, adoptar convención estática
    (`ARCHITECTURE.md` §3).

## 🟡 Media — mejoras de calidad, no bloqueantes

11. **`Promise:Await()` usa espera activa** (`repeat task.wait() until self._resolved`)
    en vez de un mecanismo basado en eventos; además no soporta `:andThen`/`:catch` ni
    múltiples valores de retorno. Ver `PERFORMANCE_PLAN.md`.

12. **Módulos propios `Promise`/`Signal` duplican paquetes ya declarados en Wally**
    (`evaera/promise`, `sleitnick/signal`). Decidir una única fuente de verdad.

13. **`PlayerService.lua` usa `Instance.new("BindableEvent")`** en vez del módulo
    `Shared/Modules/Signal` (o el paquete Wally equivalente) — tercer patrón de eventos
    en el mismo codebase.

14. **`print()` de debug sin pasar por `Logger`** en `GameService.lua` y
    `NotificationService.lua` — inconsistente con `Shared/Core/Logger.lua`, que ya
    existe para este propósito.

15. **Formato inconsistente** (mezcla de tabs/espacios, `x+=y` sin espacios en algunos
    archivos vs. `x = y` espaciado en otros) — nunca se corrió `stylua`. Ver
    `CODING_STANDARD.md`.

16. **Módulos sin `--!strict`**: `Promise.lua`, `Signal.lua`, `Shared/Bootstrap.lua`,
    `ServiceRegistry.lua`, `ControllerRegistry.lua`.

17. **`Shared/Bootstrap.lua` vs `Shared/Core/Game.lua`**: ambos imprimen un mensaje de
    "inicio" con número de versión distinto ("3.0" vs. `GameConfig.Version = "3.0.0"`) y
    no está claro cuál reemplaza a cuál. Ninguno de los dos `require`s al otro.

## 🟢 Baja — housekeeping

18. **Sin `Packages` mapeado en `default.project.json`** — bloquea el uso de cualquier
    paquete Wally aunque se instale. Ver `MIGRATION_PLAN.md` fase 0.

19. **Sin tests** (no hay `TestEZ` ni carpeta de tests) — ver `ROADMAP.md`.

20. **Sin CI** (no hay `.github/workflows`) — nada corre `selene`/`stylua --check`/
    `rojo build` automáticamente; así es como los bugs críticos #1–#4 llegaron al
    repositorio sin detectarse. Ver `ROADMAP.md`.

21. **`src/Sounds`/`src/Replicated/Sounds` y `src/UI`/`src/Replicated/UI`** sin
    documentación de propósito hasta esta auditoría (ver `PROJECT_STRUCTURE.md`,
    nota final). Recomendado renombrar para claridad cuando se pueble contenido.
