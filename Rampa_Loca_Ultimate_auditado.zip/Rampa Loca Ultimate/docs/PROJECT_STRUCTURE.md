# PROJECT_STRUCTURE.md

Leyenda de estado: ✅ Implementado y coherente · ⚠️ Implementado pero con problemas
(ver `TECH_DEBT.md`) · ⬜ Placeholder vacío (carpeta reservada, sin contenido aún).

```
.
├── .gitignore                          ✅
├── CLAUDE.md                           ✅ reglas de proyecto para asistentes de código
├── README.md                           ✅ reglas de arquitectura y convenciones
├── aftman.toml                         ✅ pines de rojo/wally/stylua/selene
├── default.project.json                ✅ árbol de Rojo (corregido en esta auditoría)
├── selene.toml                         ✅ configuración de lint
├── stylua.toml                         ✅ configuración de formateo
├── wally.toml                          ⚠️ dependencias declaradas, ninguna instalada/usada
├── docs/                               ✅ esta auditoría
└── src/
    ├── Client/                         → StarterPlayer.StarterPlayerScripts
    │   ├── Bootstrap.client.lua        ⚠️ arranca Game, pero Game nunca registra controllers
    │   ├── Camera/                     ⬜
    │   ├── Controllers/
    │   │   └── ControllerRegistry.lua  ⚠️ mecanismo de registro no conectado al bootstrap
    │   ├── Effects/                    ⬜
    │   ├── Input/                      ⬜
    │   ├── UI/                         ⬜
    │   └── Weapons/                    ⬜ (fuera de alcance de esta auditoría)
    │
    ├── Lighting/                       ⬜ → Lighting (Instances de Studio)
    │
    ├── Replicated/                     → ReplicatedStorage (raíz)
    │   ├── Animations/                 ⬜
    │   ├── Assets/                     ⬜
    │   ├── FX/                         ⬜
    │   ├── Remotes/                    ⬜ vacío; convención estática pendiente de adoptar
    │   ├── Sounds/                     ⬜ distinto de src/Sounds — ver nota abajo
    │   └── UI/                         ⬜ distinto de src/UI — ver nota abajo
    │
    ├── Server/                         → ServerScriptService
    │   ├── Bootstrap.server.lua        ⚠️ arranca Game, pero Game nunca registra services
    │   ├── Controllers/                ⬜ (vacío; no debería existir lógica de Controller
    │   │                                  en el servidor — revisar en migración)
    │   ├── ServiceLoader.lua           ⚠️ mecanismo alterno de arranque, no usado por Bootstrap
    │   ├── Services/
    │   │   ├── DataService.lua         ✅ (corregido en esta auditoría) — candidato a envolver ProfileStore
    │   │   ├── EconomyService.lua      ⚠️ no registrado en ningún registry activo
    │   │   ├── GameService.lua         ⚠️ registry duplicado, compite con Shared/Core/Game.lua
    │   │   ├── NotificationService.lua ⚠️ no registrado
    │   │   ├── PlayerService.lua       ⚠️ usa BindableEvent en vez de Shared/Modules/Signal
    │   │   ├── ProfileService.lua      ⚠️ DefaultProfile duplicado/incompatible con ProfileTemplate
    │   │   ├── RemoteService.lua       ⚠️ crea remotos en runtime, no vía Rojo estático
    │   │   ├── RewardService.lua       ⚠️ no registrado
    │   │   └── ServiceRegistry.lua     ⚠️ tercer mecanismo de registro, no usado
    │   └── Systems/                    ⬜
    │
    ├── Shared/                         → ReplicatedStorage.Shared (mapeo añadido en esta auditoría)
    │   ├── Bootstrap.lua               ⚠️ imprime versión "3.0"; GameConfig dice "3.0.0" — no se referencian entre sí
    │   ├── Config/
    │   │   ├── EconomyConfig.lua       ⚠️ solapa con GameConstants.Rewards (ver TECH_DEBT)
    │   │   ├── GameConfig.lua          ⚠️ solapa con GameConstants
    │   │   ├── GameConstants.lua       ⚠️ solapa con GameConfig/MatchConfig/EconomyConfig
    │   │   ├── MatchConfig.lua         ⚠️ solapa con GameConstants.Match (valores distintos)
    │   │   └── ProfileTemplate.lua     ⚠️ 3ra forma de "perfil por defecto", incompatible con las otras 2
    │   ├── Constants/                  ⬜
    │   ├── Core/
    │   │   ├── Game.lua                ✅ único orquestador recomendado (ver ARCHITECTURE.md)
    │   │   └── Logger.lua              ✅
    │   ├── Enums/
    │   │   ├── GameMode.lua            ✅
    │   │   ├── MatchResult.lua         ✅
    │   │   └── MatchState.lua          ✅
    │   ├── Modules/
    │   │   ├── Promise.lua             ⚠️ implementación propia, duplica evaera/promise (Wally)
    │   │   └── Signal.lua              ⚠️ implementación propia, duplica sleitnick/signal (Wally)
    │   ├── Types/                      ⬜
    │   └── Utilities/                  ⬜
    │
    ├── Sounds/                         ⬜ → SoundService (Instances de Sound reales)
    ├── UI/                             ⬜ → StarterGui (solo Instances, sin lógica — regla CLAUDE.md)
    └── Workspace/                      ⬜ → Workspace (mundo estático de Studio)
```

## Nota — `src/Sounds` vs `src/Replicated/Sounds`, `src/UI` vs `src/Replicated/UI`

Son carpetas **distintas y no duplicadas por error**, pero su propósito no está
documentado en ningún lado hasta ahora:

- `src/Sounds` → `SoundService`: instancias `Sound` reales que Studio necesita ver como
  objetos del `DataModel`.
- `src/Replicated/Sounds` → `ReplicatedStorage`: previsiblemente destinado a
  definiciones/IDs de sonido consumidos por código (no instancias), o assets que el
  cliente debe poder clonar bajo demanda.
- Mismo patrón para `UI` (`StarterGui` = Instances puros sin lógica, por regla explícita
  de `CLAUDE.md`) vs `Replicated/UI` (plantillas de UI que los `Controllers` clonarán).

Recomendación para evitar confusión futura: renombrar `src/Replicated/UI` →
`src/Replicated/UITemplates` y `src/Replicated/Sounds` → `src/Replicated/SoundDefinitions`
cuando se empiece a poblar contenido (fuera de alcance de esta auditoría — ver
`MIGRATION_PLAN.md`).
