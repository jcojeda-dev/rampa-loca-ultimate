# ROADMAP.md

## Fase actual — Fundación (esta auditoría)

- [x] Auditoría estructural completa (`PROJECT_ANALYSIS.md`).
- [x] Corrección de bugs críticos de Rojo (mapeo `Shared`, casing `Client`,
      `require` roto en `DataService`).
- [x] Normalización de finales de línea y housekeeping de Git (`.gitkeep`, carpeta
      anidada basura eliminada).
- [x] Documentación completa (`ARCHITECTURE.md`, `PROJECT_STRUCTURE.md`,
      `CODING_STANDARD.md`, `DEPENDENCY_GRAPH.md`, `TECH_DEBT.md`,
      `MIGRATION_PLAN.md`, `PERFORMANCE_PLAN.md`, `SECURITY_PLAN.md`).
- [x] Protección de secretos (`.env` ignorado, plantilla `.env.example`).

## Fase 1 — Toolchain y CI (bloqueante para todo lo demás)

- [ ] `aftman install` + `wally install`, añadir mapeo `Packages` a
      `default.project.json` (`MIGRATION_PLAN.md` fase 0).
- [ ] GitHub Actions: `rojo build` + `selene .` + `stylua --check .` en cada PR.
      Esto habría detectado los bugs críticos #1–#3 de `TECH_DEBT.md` antes de llegar
      al repositorio.
- [ ] Definir estructura mínima de tests (`TestEZ` u otro runner Luau) — sin tests
      hoy.

## Fase 2 — Consolidación de framework (sin gameplay)

- [ ] Ejecutar `MIGRATION_PLAN.md` fases 1–3 completas: config unificada, perfil de
      jugador unificado, orquestador único, `ProfileStore`, remotos estáticos,
      primitiva de eventos única.
- [ ] Cobertura de tests sobre `Shared/Core/Game.lua` (registro/arranque de
      servicios y controllers) y `DataService` (carga/guardado/fallback).

## Fase 3 — Framework listo para gameplay (checkpoint)

Criterio de salida de esta fase (y de esta auditoría): un servidor puede arrancar,
registrar todos los servicios reales, cargar/guardar el perfil de un jugador con
`ProfileStore`, y disparar/recibir al menos un remoto de ejemplo end-to-end, todo
cubierto por CI en verde. **A partir de aquí empieza el trabajo explícitamente excluido
de esta auditoría:**

- [ ] `CombatService` / sistema de daño (vida solo mutable por servidor, ver
      `SECURITY_PLAN.md`).
- [ ] `MatchService` (estados de partida usando `Shared/Enums/MatchState.lua`, ya
      existente y sin usar).
- [ ] Armas (`Client/Weapons`, `Server/Systems` — ambas carpetas ya reservadas, vacías).
- [ ] HUD (`Client/UI`, `src/Replicated/UI` como plantillas — ver nota de
      `PROJECT_STRUCTURE.md`).
- [ ] Sistema de recompensas conectado a partidas reales (`RewardService`, hoy
      huérfano — ver `DEPENDENCY_GRAPH.md`).

## Fase 4 — Contenido y balance (posterior)

- [ ] Battle Pass (`GameConfig.EnableBattlePass = true`, flag ya declarado, sin
      sistema).
- [ ] Recompensas diarias (`GameConfig.EnableDailyRewards = true`, ídem).
- [ ] Analítica (`GameConfig.EnableAnalytics = true`, ídem).
- [ ] Anti-cheat real detrás de `GameConfig.EnableAntiCheat = true`
      (ver `SECURITY_PLAN.md` §5).

---

**Nota:** las fases 3 y 4 se listan solo para dar continuidad y trazabilidad al roadmap;
por instrucción explícita de esta auditoría, no se ha escrito código de gameplay, armas,
HUD ni `MatchService` en esta sesión.
