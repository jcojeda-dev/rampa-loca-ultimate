# ARCHITECTURE.md

## 1. Capas

El proyecto sigue una arquitectura de 4 capas, ya declarada en `README.md` y `CLAUDE.md`.
Esta auditoría la formaliza y la ata al árbol real de Rojo:

| Capa | Carpeta fuente | Destino en el DataModel | Visibilidad |
|------|-----------------|--------------------------|-------------|
| Server | `src/Server` | `ServerScriptService` | Solo servidor |
| Client | `src/Client` | `StarterPlayer.StarterPlayerScripts` | Solo ese cliente |
| Shared | `src/Shared` | `ReplicatedStorage.Shared` | Servidor + todos los clientes (código) |
| Replicated | `src/Replicated` | `ReplicatedStorage` (raíz) | Servidor + todos los clientes (assets/remotos) |
| UI | `src/UI` | `StarterGui` | Solo ese cliente (solo Instances, **nunca lógica**) |
| Sounds | `src/Sounds` | `SoundService` | Global |
| Workspace | `src/Workspace` | `Workspace` | Global (mundo estático) |
| Lighting | `src/Lighting` | `Lighting` | Global |

**Regla dura (ya en `CLAUDE.md`, reforzada aquí):** ninguna capa accede directamente a
otra. Toda comunicación Cliente ⇄ Servidor pasa por `Remotes`; toda lectura/escritura de
estado de juego pasa por un `Service` (servidor) o `Controller` (cliente), nunca por
acceso directo a `leaderstats`, `Humanoid.Health` o DataStores.

`Shared` es la única carpeta con visibilidad simultánea servidor+cliente para **código**
(config, enums, tipos, utilidades, módulos puros). No debe contener estado mutable
compartido por referencia entre servidor y cliente (Roblox no comparte memoria entre
ellos; cada uno tiene su propia copia del módulo).

## 2. Patrón de servicios/controladores (a unificar)

Estado actual: **4 mecanismos distintos coexisten sin integración** (ver `TECH_DEBT.md`
para el detalle). Arquitectura objetivo — **un único patrón**:

```
Bootstrap.server.lua / Bootstrap.client.lua
        │
        ▼
  Shared/Core/Game.lua   (único orquestador, Init → Start, servicios y controllers)
        │
        ├── RegisterService(name, ServiceModule)   -- servidor
        └── RegisterController(name, ControllerModule) -- cliente
```

`Game.lua` (en `Shared/Core`) se conserva como único punto de entrada porque ya es
compartido por ambas capas y ya implementa el ciclo `Init` → `Start` con
`task.spawn` para no bloquear el hilo principal. **Se deprecan** `GameService.lua`,
`ServiceRegistry.lua` y `ServiceLoader.lua` como mecanismos de arranque paralelos
(quedan documentados en `TECH_DEBT.md` como candidatos a eliminación en
`MIGRATION_PLAN.md`, no se tocan en esta auditoría por ser decisión de diseño).

Cada `Service`/`Controller` debe exponer, como máximo:

- `:Init()` — configuración síncrona, sin efectos secundarios de red.
- `:Start()` — arranque real (conexiones a eventos, bucles).
- `:Update(dt)` — opcional, solo si necesita tick por frame.

## 3. Networking

Fuente de verdad única: **Rojo estático**. Los `RemoteEvent`/`RemoteFunction` se definen
como archivos/carpetas versionados bajo `src/Replicated/Remotes`, no se crean en runtime
vía `Instance.new` (patrón actual de `RemoteService.lua`, deprecar — ver `TECH_DEBT.md`).
Esto permite:

- Trazabilidad en revisiones de código (diff visible de qué remotos existen).
- Tipado de payloads documentado junto al remoto.
- Cero riesgo de condiciones de carrera entre creación del remoto y su primer uso.

Todo remoto entrante al servidor debe validarse (tipo, rango, rate-limit) antes de tocar
cualquier `Service`. Ver `SECURITY_PLAN.md`.

## 4. Configuración

Objetivo: **una sola fuente de verdad** por dominio, en `Shared/Config/`:

- `GameConfig` — parámetros globales del juego (nombre, versión, flags de features).
- `MatchConfig` — todo lo relativo a duración/estados de partida.
- `EconomyConfig` — recompensas y límites económicos.
- `ProfileTemplate` — única forma del perfil persistido por jugador.

`GameConstants.lua` y `ProfileService.DefaultProfile` se consolidan dentro de los
anteriores (ver `MIGRATION_PLAN.md`, fase 1). Ningún valor de balance debe existir en
más de un archivo.

## 5. Persistencia

Objetivo: `DataService` deja de llamar a `DataStoreService` directamente y se convierte en
una fachada delgada sobre el paquete ya declarado en Wally `lm-loleris/profilestore`
(`ProfileStore`), que aporta session-locking, reintentos y protección contra
sobrescritura — capacidades que la implementación actual no tiene. Detalle en
`MIGRATION_PLAN.md`.

## 6. Diagrama de flujo (alto nivel)

```
Cliente                          Servidor
───────                          ────────
Bootstrap.client.lua             Bootstrap.server.lua
   │                                 │
   ▼                                 ▼
Game:Start() (Shared/Core)     Game:Start() (Shared/Core)
   │                                 │
   ▼                                 ▼
Controllers (Client/Controllers) Services (Server/Services)
   │                                 │
   └──────────► Remotes ◄────────────┘
          (src/Replicated/Remotes, estáticos)
```

## 7. Módulos compartidos (`Shared/Modules`)

`Promise.lua` y `Signal.lua` son implementaciones propias, minimalistas y **no
equivalentes** a los paquetes homónimos ya declarados en `wally.toml`
(`evaera/promise`, `sleitnick/signal`). Mantener ambos es duplicación de
responsabilidad. Recomendación (ver `MIGRATION_PLAN.md`): adoptar los paquetes de
Wally como estándar y retirar las implementaciones caseras, o —si se opta por
mantenerlas por control total— eliminar las dependencias de Wally equivalentes de
`wally.toml` para evitar ambigüedad sobre cuál es la fuente de verdad.
