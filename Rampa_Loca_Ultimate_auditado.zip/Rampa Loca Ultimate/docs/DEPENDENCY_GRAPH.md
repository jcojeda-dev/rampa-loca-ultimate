# DEPENDENCY_GRAPH.md

## 1. Grafo de `require()` real (extraído del código, no aspiracional)

```
Server/Bootstrap.server.lua
  ├── require(ReplicatedStorage.Shared.Core.Game)
  └── require(ReplicatedStorage.Shared.Core.Logger)

Client/Bootstrap.client.lua
  └── require(ReplicatedStorage.Shared.Core.Game)

Server/Services/RewardService.lua
  └── require(ReplicatedStorage.Shared.Config.GameConstants)

Server/Services/DataService.lua
  └── require(ReplicatedStorage.Shared.Config.ProfileTemplate)

Server/ServiceLoader.lua
  └── require(module)   -- dinámico, itera ServerScriptService.Services
```

### Lectura del grafo

- Solo **6 de 26 archivos** tienen algún `require` explícito. El resto (`EconomyService`,
  `PlayerService`, `NotificationService`, `ProfileService`, `RemoteService`,
  `GameService`, `ServiceRegistry`, `ControllerRegistry`, todos los `Enums`, todos los
  módulos de `Shared/Modules`) **no importan nada ni son importados por nadie** todavía.
  Son código "huérfano": existe pero no está conectado al grafo de ejecución real.
- `Shared/Core/Game.lua` es el único módulo requerido tanto por servidor como por
  cliente — confirma que es el candidato correcto a único orquestador (`ARCHITECTURE.md`).
- Ningún archivo bajo `Server/Services/*` (excepto `RewardService` y `DataService`)
  es requerido por `Bootstrap.server.lua`, `Game.lua` ni por ningún otro archivo. Esto
  es consistente con el hallazgo de `TECH_DEBT.md`: los servicios nunca se registran ni
  arrancan.
- `Server/ServiceLoader.lua:Load()` sí itera `ServerScriptService.Services` y haría
  `require` dinámico de todo lo que encuentre — pero `ServiceLoader:Load()` en sí mismo
  no es llamado desde ningún lado (no aparece en `Bootstrap.server.lua`).

## 2. Dependencias externas (Wally) — declaradas vs. usadas

| Paquete (`wally.toml`) | Versión | ¿Instalado? | ¿Usado en código? | Nota |
|---|---|---|---|---|
| `evaera/promise` | 4.0.0 | ❌ (`Packages/` no existe) | ❌ | `Shared/Modules/Promise.lua` reimplementa una versión simplificada |
| `sleitnick/signal` | 2.0.1 | ❌ | ❌ | `Shared/Modules/Signal.lua` reimplementa una versión simplificada |
| `sleitnick/component` | 2.4.8 | ❌ | ❌ | Sin uso ni módulo propio equivalente |
| `sleitnick/trove` | 1.5.0 | ❌ | ❌ | Sin uso; sería relevante para limpieza de conexiones en `Controllers` |
| `sleitnick/comm` | 0.3.1 | ❌ | ❌ | Sin uso; solapa con la responsabilidad de `RemoteService.lua` |
| `lm-loleris/profilestore` | 1.0.3 | ❌ | ❌ | `DataService.lua` usa `DataStoreService` crudo en su lugar |
| `sleitnick/table-util` | 1.2.1 | ❌ | ❌ | `DataService.lua` reimplementa `DeepCopy` manualmente |

**Ningún paquete de Wally está instalado ni sincronizado.** `default.project.json` ni
siquiera tiene un mapeo `Packages` bajo `ReplicatedStorage`. Ejecutar `wally install` hoy
generaría una carpeta `Packages/` que **no se sincronizaría a Roblox Studio** hasta añadir
ese mapeo (ver `MIGRATION_PLAN.md`, fase 0).

## 3. Herramientas (`aftman.toml`)

| Herramienta | Versión pineada | Rol |
|---|---|---|
| `rojo` | 7.5.1 | Sincronización proyecto ⇄ Studio, build de `.rbxl` |
| `wally` | 0.3.2 | Gestor de paquetes Luau |
| `stylua` | 0.20.0 | Formateador (ver `CODING_STANDARD.md`) |
| `selene` | 0.27.1 | Linter (ver `CODING_STANDARD.md`) |

Ninguna se ejecutó en esta auditoría (entorno sandbox sin acceso a los binarios de
Roblox tooling); se recomienda que el primer workflow de CI (`ROADMAP.md`) las instale
vía `aftman install` y las corra sobre cada PR.

## 4. Dependencias circulares

No se detectaron (el grafo actual es casi todo hojas sin conexión — ver §1). El riesgo
de ciclos aparecerá al conectar los `Service`/`Controller` reales entre sí; la regla de
`ARCHITECTURE.md` (acceso solo vía `Game:GetService`/`GetController`, nunca `require`
directo entre dos `Service`) previene ciclos de `require` por diseño.
