# CODING_STANDARD.md

Complementa (no reemplaza) `CLAUDE.md` y `README.md`, que siguen siendo la fuente de
verdad de las reglas de arquitectura del proyecto. Este documento cubre estilo de código
concreto, ya que `stylua`/`selene` están configurados pero nunca se ejecutaron sobre el
código existente (todo el repo tenía finales de línea no estándar hasta esta auditoría).

## 1. Formato

Gobernado por `stylua.toml`:

- Ancho de columna: 120.
- Indentación: 4 espacios (no tabs) — **el código actual mezcla tabs y espacios**;
  ejecutar `stylua .` antes de cada commit lo corrige automáticamente.
- Finales de línea: `Unix` (LF). Ya normalizado en esta auditoría.
- Comillas: dobles, preferidas automáticamente (`AutoPreferDouble`).
- Llamadas a función: siempre con paréntesis (`call_parentheses = "Always"`).

Regla operativa: **ningún PR se mergea sin `stylua --check .` en verde.**

## 2. Lint

Gobernado por `selene.toml` (`std = "roblox"`):

- `undefined_variable = "deny"` — error duro, bloquea CI.
- `shadowing`, `unused_variable`, `global_usage` = `warn` — revisar antes de mergear.
- `multiple_statements`, `mixed_table` = `allow` — permitido por convención de este
  proyecto (el código actual usa mucho `if x then return end` en una línea).

## 3. Tipado

Obligatorio por `CLAUDE.md`: **todo código nuevo debe incluir tipado Luau**
(`--!strict` al inicio del archivo). Ya se cumple en casi todos los módulos existentes;
excepciones a corregir: `Shared/Modules/Promise.lua`, `Shared/Modules/Signal.lua`,
`Shared/Bootstrap.lua`, `Server/Services/ServiceRegistry.lua`,
`Client/Controllers/ControllerRegistry.lua` no declaran `--!strict`.

Prácticas mínimas:

- Declarar `type X = {...}` para cualquier tabla que se pase entre funciones o módulos
  (ej. `PlayerProfile` en `PlayerService.lua`, buen ejemplo a replicar).
- Tipar explícitamente los parámetros de funciones públicas de `Service`/`Controller`
  (`function X:Method(player: Player, amount: number)`).
- Evitar `any` salvo en fronteras genuinamente dinámicas (ej. payload crudo de
  `DataStoreService` antes de validarlo).

## 4. Tamaño de archivo

`CLAUDE.md`: máximo 400 líneas por script; si se supera, dividir. Ningún archivo actual
lo excede (el más largo, `PlayerService.lua`, tiene 156 líneas reales).

## 5. Nomenclatura

- `PascalCase` para módulos, carpetas de capa (`Server`, `Client`, `Shared`,
  `Replicated`) y tipos.
- `PascalCase.Method` para métodos públicos de `Service`/`Controller`
  (`Service:Start()`, no `Service:start()`).
- Prohibido nombrar scripts `Script`, `LocalScript` o `ModuleScript` (regla ya en
  `README.md`).
- Sufijos obligatorios: `*Service` (servidor), `*Controller` (cliente), `*Config`
  (constantes de balance), `*Registry`/`*Loader` reservados para el único orquestador
  definido en `ARCHITECTURE.md` — no crear nuevos registries paralelos.

## 6. Errores y control de flujo

- `task.wait()`/`task.spawn()` — nunca `wait()`/`spawn()` (ya se cumple en el código
  existente).
- Toda llamada a una API que puede fallar por red (`DataStoreService`, `MarketplaceService`,
  `HttpService`) va envuelta en `pcall` y su fallo se registra vía `Shared/Core/Logger`,
  nunca con `print` suelto (excepción actual a corregir: varios `print(...)` de debug en
  `GameService.lua`, `NotificationService.lua`, deberían pasar por `Logger`).
- No usar bucles de espera activa (`repeat task.wait() until condicion`) salvo que no
  exista alternativa basada en eventos — el `Promise:Await()` actual en
  `Shared/Modules/Promise.lua` es un ejemplo a corregir (ver `TECH_DEBT.md` y
  `PERFORMANCE_PLAN.md`).

## 7. Comunicación cliente-servidor

Ningún `Service` accede a otro `Service` directamente por variable global; toda
referencia cruzada pasa por `Game:GetService(name)` / `Game:GetController(name)` una vez
unificado el orquestador (ver `ARCHITECTURE.md`). Los remotos siguen la convención
definida en `ARCHITECTURE.md` §3 (estáticos, versionados en `src/Replicated/Remotes`).

## 8. Config/balance

Ningún número mágico de balance (recompensas, tiempos, límites) se escribe inline en un
`Service`. Siempre se referencia desde `Shared/Config/*`, y solo desde uno de esos
archivos por concepto (ver plan de consolidación en `MIGRATION_PLAN.md`).
